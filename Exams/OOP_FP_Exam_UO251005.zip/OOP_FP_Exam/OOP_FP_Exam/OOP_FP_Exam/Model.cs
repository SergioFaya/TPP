﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_FP_Exam
{
    public class Videogame
    {
        public Videogame(string name, string genre, int ry)
        {
            Name = name;
            Genre = genre;
            ReleaseYear = ry;
        }


        public string Name { get; set; }
        public string Genre { get; set; }
        public int ReleaseYear { get; set; }
        
        public override string ToString()
        {
            return String.Format("[Videogame: {0}]", Name);
        }
    }
    
    public class Player
    {
        public Player(string name, string country, int yob, IEnumerable<Videogame> videogames)
        {
            Name = name;
            Country = country;
            YearOfBirth = yob;
            Videogames = videogames;
        }

        public string Name { get; set; }
        public string Country { get; set; }
        public int YearOfBirth { get; set; }
        public IEnumerable<Videogame> Videogames { get; set; }

        public override string ToString()
        {
            return String.Format("[Player: {0}]", Name);
        }
    }
    
    
    public class Model
    {
        public IList<Videogame> Videogames { get { return videogames; } }
        public IList<Player> Players { get { return players; } }
        
        static Model()
        {
            ResetModel();
        }

        private static void ResetModel()
        {
            videogames = new List<Videogame> 
            {
                new Videogame("Super Mario 64", "Platformer",1996), 
                new Videogame("The Legend of Zelda", "Action-adventure", 1986),
                new Videogame("The Secret of Monkey Island", "Graphic adventure",1990),
                new Videogame("Red Dead Redemption", "Action-adventure",2010),
                new Videogame("StarCraft", "Real-time strategy",1998),
                new Videogame("World of Warcraft", "MMORPG",2004),
                new Videogame("Age of Empires II", "Real-time strategy",1999),
                new Videogame("Halo 3", "First-person shooter",2007),
                new Videogame("Uncharted 4: A Thief's End", "Action-adventure",2016),
                new Videogame("The Elder Scrolls V: Skyrim", "Action role-playing",2011),
                new Videogame("The Witcher 3: Wild Hunt", "Action role-playing",2015),
                new Videogame("Dark Souls", "Action role-playing",2011)
            };
            
            players = new List<Player>
            {
                new Player("Luis", "Spain", 1998, new List<Videogame> {videogames[0], videogames[2]}),
                new Player("Mary", "USA", 1970, new List<Videogame> {videogames[1], videogames[4], videogames[6], videogames[8]}),
                new Player("Shigeru", "Japan", 1980, new List<Videogame> {videogames[1], videogames[2], videogames[10]}),
                new Player("Antonio", "Spain", 1996, new List<Videogame> {videogames[10]}),
                new Player("James", "UK", 2000, new List<Videogame> {videogames[8]}),
                new Player("John", "USA", 1986, new List<Videogame> {videogames[0], videogames[11], videogames[3], videogames[5]}),
                new Player("Lucy", "USA", 1984, new List<Videogame> {videogames[1], videogames[9]}),
                new Player("Oliver", "France", 2001, new List<Videogame> {videogames[7], videogames[2], videogames[8]}),
                new Player("Niklas", "Denmark", 1986, new List<Videogame> {videogames[1]})
            };
        }

        private static List<Videogame> videogames;
        private static List<Player> players;
    }
}
