﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_FP_Exam
{
    public class ExamClass
    {
        private object examProperty;
        public static int NumberOfConstructedClasses = 0;
        public object ExamProperty {
            get{
                NReadsExamProperty++;
                return examProperty;
            }
            set
            {
                examProperty = value;
            }

        }
        public int NReadsExamProperty { get; set; }

        public int NumberOfInstantiations()
        {
            return NumberOfConstructedClasses;
        }

        public void ExamMethodInOutRef(ref object a)
        {
            object temp = a;
            a = ExamProperty;
            ExamProperty = temp;
        }

        public override bool Equals(object obj)
        {
            if(obj is ExamClass && (obj as ExamClass).NReadsExamProperty == NReadsExamProperty )
            {
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return this.GetHashCode();
        }
    }
}
