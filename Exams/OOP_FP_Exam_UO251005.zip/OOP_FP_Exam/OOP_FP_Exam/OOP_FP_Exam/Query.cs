﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OOP_FP_Exam
{
    class Query
    {
        private Model model = new Model();

        private void Query1()
        {
            // Show the oldest player that plays "Super Mario 64". Assume that there is only one player that fulfills that condition.
            
            Console.WriteLine();
            Console.WriteLine("*** *** *** QUERY 1 *** *** ***");

            Videogame mario = model.Videogames.First(v => v.Name == "Super Mario 64");
            var oldest = model.Players.Where(p => p.Videogames.Contains(mario)).OrderBy(p => p.YearOfBirth).First();
            Console.WriteLine(oldest);
            Console.WriteLine();

        }

        private void Query2()
        {
            // Show the pairs of player-videogame that were born/released the same year.
            
            Console.WriteLine();
            Console.WriteLine("*** *** *** QUERY 2 *** *** ***");
            var q = model.Players.Join(model.Videogames,
                e => e.YearOfBirth,
                v => v.ReleaseYear,
                (e, v) => new { Name = e.Name, VGName = v.Name });
            foreach (var item in q)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        
        }

        private void Query3()
        {
            // Show the players that have the most games.

            Console.WriteLine();
            Console.WriteLine("*** *** *** QUERY 3 *** *** ***");

            var maxGames = model.Players.Max(p => p.Videogames.Count());
            var q = model.Players.Where(p => p.Videogames.Count() == maxGames);
            foreach (var item in q)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        
        }

        private void Query4()
        {
            // Show videogames grouped by genre.

            Console.WriteLine();
            Console.WriteLine("*** *** *** QUERY 4 *** *** ***");
            var q = model.Videogames.GroupBy(v => v.Genre);

            foreach (var item in q)
            {
                Console.WriteLine(item.Key);
                foreach (var o in item)
                {
                    Console.WriteLine("\t"+o);
                }
            }
            Console.WriteLine();
        }


        static void Main(string[] args)
        {
            Query query = new Query();

            query.Query1();
            query.Query2();
            query.Query3();
            query.Query4();
            
            Console.ReadLine();
        }
    }
}
