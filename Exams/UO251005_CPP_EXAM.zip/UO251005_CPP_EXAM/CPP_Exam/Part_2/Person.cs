﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    public class Person
    {
        public int Id { get; set; }
        public int Age { get; set; }
        public string Country { get; set; }
        public string FavouriteFruit { get; set; }

        public Person(int id, int age, string country, string ff)
        {
            Id = id;
            Age = age;
            Country = country;
            FavouriteFruit = ff;
        }

    }
}
