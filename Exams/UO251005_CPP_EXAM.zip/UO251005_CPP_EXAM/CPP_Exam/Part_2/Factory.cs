﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    public class Factory
    {
        public static Person[] CreatePeople()
        {
            int number_people = 100000;

            Person[] people = new Person[number_people]; Random random = new Random();

            string[] fruits = { "Apples", "Oranges", "Strawberries", "Pineapples", "Peaches" };

            string[] countries = { "Spain", "UK", "France", "USA", "Netherlands" };

            for (int i = 0; i < number_people; i++)
            {
                people[i] = new Person(i, random.Next(0, 100), countries[random.Next(countries.Length)], fruits[random.Next(fruits.Length)]);
            }
            
            return people;
        }

    }
}
