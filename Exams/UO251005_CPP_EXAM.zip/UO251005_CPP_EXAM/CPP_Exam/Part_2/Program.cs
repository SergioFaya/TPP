﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
namespace Part_2
{
    class Program
    {
        public static object _lockerPeaches = new object();//locker for adding into the list of peopple who like peaches
        public static object _locker = new object();

        static void Main(string[] args)
        {
            string[] fruits = { "Apples", "Oranges", "Strawberries", "Pineapples", "Peaches" };

            Person[] people = Factory.CreatePeople();

            string favourite_fruit_all,
                favourite_fruit_young,
                favourite_fruit_middle_age,
                favourite_fruit_old,
                favourite_fruit_Spain,
                favourite_fruit_UK,
                favourite_fruit_France,
                favourite_fruit_USA,
                favourite_fruit_Netherlands;

            DateTime before = DateTime.Now;
            favourite_fruit_all = PeopleProcessing.FavouriteFruit(fruits, people);
            favourite_fruit_young = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Age < 30);
            favourite_fruit_middle_age = PeopleProcessing.FavouriteFruitPred(fruits, people, p => (p.Age >= 30 && p.Age < 60));
            favourite_fruit_old = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Age > 60);
            favourite_fruit_Spain = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "Spain");
            favourite_fruit_UK = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "UK");
            favourite_fruit_France = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "France");
            favourite_fruit_USA = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "USA");
            favourite_fruit_Netherlands = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "Netherlands");
            DateTime after = DateTime.Now;

            Console.WriteLine("The favourite fruit is {0}", favourite_fruit_all);
            Console.WriteLine("The favourite fruit of the young people is {0}", favourite_fruit_young);
            Console.WriteLine("The favourite fruit of the middle-age people is {0}", favourite_fruit_middle_age);
            Console.WriteLine("The favourite fruit of the old people is {0}", favourite_fruit_old);
            Console.WriteLine("The favourite fruit of the people from Spain is {0}", favourite_fruit_Spain);
            Console.WriteLine("The favourite fruit of the people from the UK is {0}", favourite_fruit_UK);
            Console.WriteLine("The favourite fruit of the people from France is {0}", favourite_fruit_France);
            Console.WriteLine("The favourite fruit of the people from the USA is {0}", favourite_fruit_USA);
            Console.WriteLine("The favourite fruit of the people from the Netherlands is {0}", favourite_fruit_Netherlands);

            Console.WriteLine("\nElapsed time: {0:N} milliseconds.", (after - before).Ticks / TimeSpan.TicksPerMillisecond);






            // Exercise 1
            // Do the same tasks that are done in the example but in parallel
            Console.WriteLine("**************************************************************");
            Console.WriteLine("Exercise 1");
            DateTime before2 = DateTime.Now;

            Parallel.Invoke(()=> favourite_fruit_all = PeopleProcessing.FavouriteFruit(fruits, people));
            Parallel.Invoke(() => favourite_fruit_young = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Age < 30));
            Parallel.Invoke(() => favourite_fruit_middle_age = PeopleProcessing.FavouriteFruitPred(fruits, people, p => (p.Age >= 30 && p.Age < 60)));
            Parallel.Invoke(() => favourite_fruit_old = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Age > 60));
            Parallel.Invoke(() => favourite_fruit_Spain = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "Spain"));
            Parallel.Invoke(() => favourite_fruit_UK = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "UK"));
            Parallel.Invoke(() => favourite_fruit_France = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "France"));
            Parallel.Invoke(() => favourite_fruit_USA = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "USA"));
            Parallel.Invoke(() => favourite_fruit_Netherlands = PeopleProcessing.FavouriteFruitPred(fruits, people, p => p.Country == "Netherlands"));
            DateTime after2 = DateTime.Now;

            Console.WriteLine("The favourite fruit is {0}", favourite_fruit_all);
            Console.WriteLine("The favourite fruit of the young people is {0}", favourite_fruit_young);
            Console.WriteLine("The favourite fruit of the middle-age people is {0}", favourite_fruit_middle_age);
            Console.WriteLine("The favourite fruit of the old people is {0}", favourite_fruit_old);
            Console.WriteLine("The favourite fruit of the people from Spain is {0}", favourite_fruit_Spain);
            Console.WriteLine("The favourite fruit of the people from the UK is {0}", favourite_fruit_UK);
            Console.WriteLine("The favourite fruit of the people from France is {0}", favourite_fruit_France);
            Console.WriteLine("The favourite fruit of the people from the USA is {0}", favourite_fruit_USA);
            Console.WriteLine("The favourite fruit of the people from the Netherlands is {0}", favourite_fruit_Netherlands);

            Console.WriteLine("\nElapsed time: {0:N} milliseconds.", (after2 - before2).Ticks / TimeSpan.TicksPerMillisecond);




            // Exercise 2
            // Calculate the number of people older than 30 whose favourite fruit is ‘Oranges’ or ‘Apples’ in parallel
            Console.WriteLine("**************************************************************");
            Console.WriteLine("Exercise 2");
            int counterPeople = 0;
            Parallel.ForEach(people, p =>
            {
                if(p.Age> 30)
                {
                    if(p.FavouriteFruit.Equals("Oranges") || p.FavouriteFruit.Equals("Apples"))
                    {
                        Interlocked.Increment(ref counterPeople);
                    }
                }
            });
            Console.WriteLine("Number of people older than 30 whose favourite fruis is Orange or Apples = " + counterPeople);

            // Exercise 3
            // Calculate what country has the most people whose favourite fruit is ‘Peaches’ in parallel
            Console.WriteLine("**************************************************************");
            Console.WriteLine("Exercise 3");

            List<Person> peachers = new List<Person>();
            Parallel.ForEach(people, p =>
            {
                if (p.FavouriteFruit.Equals("Peaches"))
                {
                    lock (_lockerPeaches)
                    {
                        peachers.Add(p);
                    }
                }   
            });
            peachers.OrderBy((p) => p.Country);
            int counter = 0;
            string country = peachers[0].Country;
            ConcurrentDictionary<int,string> dic = new ConcurrentDictionary<int,string>();
            Parallel.ForEach(peachers, p =>
            {
                if (country.Equals(p.Country)) {
                    Interlocked.Increment(ref counter);
                }else
                {
                    lock (_locker)
                    {
                        dic.AddOrUpdate(counter, p.Country,(c,s) => s);
                        counter = 0;
                    }
                }
            });
            var sortedDic = dic.OrderBy((d) => d.Key);
            var countryPeachers = sortedDic.First().Value;
            Console.WriteLine("The country where most peach consumers are is " + countryPeachers);
            Console.ReadLine();
        }
    }
}
