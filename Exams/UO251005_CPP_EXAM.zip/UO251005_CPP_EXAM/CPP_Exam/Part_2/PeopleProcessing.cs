﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    public static class PeopleProcessing
    {
        public static string FavouriteFruit(string[] fruits, Person[] people)
        {
            // Returns the favourite fruit for all people

            List<int> count_fruit = new List<int>();

            for (int i = 0; i < fruits.Length; ++i)
                count_fruit.Add(0);

            for (int i = 0; i < people.Length; ++i)
            {
                for (int j = 0; j < fruits.Length; ++j)
                {
                    if (people[i].FavouriteFruit == fruits[j])
                    {
                        ++count_fruit[j];
                        j = fruits.Length;
                    }
                }
            }

            int max_fav = 0;
            int ind_max_fav = -1;
            for (int i = 0; i < fruits.Length; ++i)
            {
                if (count_fruit[i] > max_fav)
                {
                    max_fav = count_fruit[i];
                    ind_max_fav = i;
                }
            }

            return fruits[ind_max_fav];
        }


        public static string FavouriteFruitPred(string[] fruits, Person[] people, Predicate<Person> p)
        {
            // Returns the favourite fruit for all people that fulfill a given predicate

            List<int> count_fruit = new List<int>();

            for (int i = 0; i < fruits.Length; ++i)
                count_fruit.Add(0);

            for (int i = 0; i < people.Length; ++i)
            {
                if (p(people[i]))
                {
                    for (int j = 0; j < fruits.Length; ++j)
                    {
                        if (people[i].FavouriteFruit == fruits[j])
                        {
                            ++count_fruit[j];
                            j = fruits.Length;
                        }
                    }
                }
            }

            int max_fav = 0;
            int ind_max_fav = -1;
            for (int i = 0; i < fruits.Length; ++i)
            {
                if (count_fruit[i] > max_fav)
                {
                    max_fav = count_fruit[i];
                    ind_max_fav = i;
                }
            }

            return fruits[ind_max_fav];
        }

    }
}
