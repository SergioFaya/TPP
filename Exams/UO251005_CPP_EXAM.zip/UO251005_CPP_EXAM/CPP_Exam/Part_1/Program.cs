﻿using System;
using System.IO;
using System.Collections.Generic;

namespace Part_1
{
    public class VectorModulusProgram
    {

        static void Main(string[] args)
        {
            short[] u = CreateRandomVector(100000, 0, 100);
            short[] v = CreateRandomVector(100000, 0, 100);
            short[] w = CreateRandomVector(100000, 0, 100);

            List<short> pairs = new List<short>();
            List<short> odds = new List<short>();


            // Do the part of showing the evolution of execution times relative to the number of threads here
            Master master;
            ShowLine(Console.Out, "Numer of Threads", "Ticks", "Result");
            for (int i = 1; i < 10; i++)
            {
                master = new Master(u, v, w, pairs, odds, i);
                DateTime before = DateTime.Now;
                double result = master.ComputeMean();
                DateTime after = DateTime.Now;
                long ticks = (after - before).Ticks;
                //Console.WriteLine(i + " THREADS");
                //Console.WriteLine("Time for getting the mean value :"+result+ " is "+ticks);
                //Console.WriteLine();
                ShowLine(Console.Out, i, (after - before).Ticks, result);
                GC.Collect(); // The garbage collector is run 
                GC.WaitForFullGCComplete();//the thread is more precise due to the thread collector
            }
            


            Console.ReadLine();
        }


        public static short[] CreateRandomVector(int numberOfElements, short lowest, short greatest)
        {
            short[] vector = new short[numberOfElements];
            Random random = new Random();
            for (int i = 0; i < numberOfElements; i++)
                vector[i] = (short)random.Next(lowest, greatest + 1);
            return vector;
        }


        private const string CSV_SEPARATOR = ";";

        static void ShowLine(TextWriter stream, string numberOfThreadsTitle, string ticksTitle, string resultTitle)
        {
            stream.WriteLine("{0}{3} {1}{3} {2}{3}", numberOfThreadsTitle, ticksTitle, resultTitle, CSV_SEPARATOR);
        }

        static void ShowLine(TextWriter stream, int numberOfThreads, long ticks, double result)
        {
            stream.WriteLine("{0}{3} {1:N0}{3} {2:N2}{3}", numberOfThreads, ticks, result, CSV_SEPARATOR);
        }

    }
}
