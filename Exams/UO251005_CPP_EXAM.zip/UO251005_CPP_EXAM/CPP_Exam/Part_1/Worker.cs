﻿using System.Collections.Generic;

namespace Part_1
{
    internal class Worker
    {
        private short[] u;
        private short[] v;
        private short[] w;

        private List<short> pairs = new List<short>();
        private List<short> odds = new List<short>();

        private int fromIndex, toIndex;

        private long result;
        //locking the access to the list
        private static object _lockerUEven = new object();
        private static object _lockerVEven = new object();
        private static object _lockerWEven = new object();
        private static object _lockerUOdd = new object();
        private static object _lockerVOdd = new object();
        private static object _lockerWOdd = new object();

        internal long Result
        {
            get { return this.result; }
        }

        internal Worker(short[] u, short[] v, short[] w, List<short> pairs, List<short> odds, int fromIndex, int toIndex)
        {
            this.u = u;
            this.v = v;
            this.w = w;

            this.pairs = pairs;
            this.odds = odds;

            this.fromIndex = fromIndex;
            this.toIndex = toIndex;
        }

        internal void Compute()
        {
            for (int i = this.fromIndex; i <= this.toIndex; i++)
            {
                if(u[i]%2 == 0)
                {
                    lock (_lockerUEven){pairs.Add(u[i]);}
                }
                if (v[i] % 2 == 0)
                {
                    lock(_lockerVEven) { pairs.Add(v[i]);}
                }
                if (w[i] % 2 == 0)
                {
                    lock (_lockerWEven) { pairs.Add(w[i]); }
                }

                if (u[i] % 2 != 0)
                {
                    lock (_lockerUOdd) { odds.Add(u[i]); }
                }
                if (v[i] % 2 != 0)
                {
                    lock (_lockerVOdd) { odds.Add(v[i]); }
                }
                if (v[i] % 2 != 0)
                {
                    lock (_lockerWOdd) { odds.Add(w[i]); }
                }

                this.result += this.u[i] + this.v[i] - this.w[i];
            } 
        }
    }
}
