﻿using System;
using System.Threading;
using System.Collections.Generic;

namespace Part_1
{
    public class Master
    {
        private short[] u;
        private short[] v;
        private short[] w;

        private List<short> pairs = new List<short>();
        private List<short> odds = new List<short>();

        private int numberOfThreads;

        public Master(short[] u, short[] v, short[] w, List<short> pairs, List<short> odds, int numberOfThreads)
        {
            if (numberOfThreads < 1 || numberOfThreads > u.Length)
                throw new ArgumentException("The number of threads must be lower or equal to the elements of the vector");

            this.u = u;
            this.v = v;
            this.w = w;
            this.pairs = pairs;
            this.odds = odds;
  
            this.numberOfThreads = numberOfThreads;
        }

        public double  ComputeMean()
        {
            Worker[] workers = new Worker[this.numberOfThreads];
            int elementsPerThread = this.u.Length / numberOfThreads;
            for (int i = 0; i < this.numberOfThreads; i++)
                workers[i] = new Worker(this.u,this.v,this.w,this.pairs,this.odds,
                    i * elementsPerThread,//From
                    (i < this.numberOfThreads - 1) ? (i + 1) * elementsPerThread - 1 : this.u.Length - 1); // to

            Thread[] threads = new Thread[workers.Length];
            for (int i = 0; i < workers.Length; i++)
            {
                threads[i] = new Thread(workers[i].Compute); 
                threads[i].Name = "Vector mean u+v-w " + (i + 1); // we name then (optional)
                threads[i].Priority = ThreadPriority.Normal; // we assign them a priority (optional)
                threads[i].Start();   // we start their execution
            }

            foreach (Thread thread in threads)
                thread.Join();

            //Computing final solution
            long result = 0;
            for (int i = 0 ; i < workers.Length; i++)
            {
                result += workers[i].Result;
            }

            return result / u.Length;
        }

    }
}